
   
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2 style="font-size:1rem;">文房具登録画面</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="<?php echo e(url('/juchus')); ?>">戻る</a>
        </div>
    </div>
</div>
 
<div style="text-align:right;">
    <form action="<?php echo e(route('juchu.update',$juchu->id)); ?>" method="POST">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
         
         <div class="row">
            <div class="col-12 mb-2 mt-2 mb-2">
                <div class="form-group">
                    <select name="kyakusaki_id" class="form-select">
                        <option>客先を選択してください</otion>
                        <?php $__currentLoopData = $kyakusakis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kyakusaki): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kyakusaki->id); ?>"<?php if($kyakusaki->id==$juchu->kyakusaki_id): ?> selected <?php endif; ?>><?php echo e($kyakusaki->name); ?></otion>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['kyakusaki_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red;">客先を選択してください</span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-12 mb-2 mt-2 mb-2">
                <div class="form-group">
                    <select name="bunbougu_id" class="form-select">
                        <option>文房具を選択してください</otion>
                        <?php $__currentLoopData = $bunbougus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bunbougu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bunbougu->id); ?>"<?php if($bunbougu->id==$juchu->bunbougu_id): ?> selected <?php endif; ?>><?php echo e($bunbougu->name); ?></otion>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['bunbougu_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red;">文房具を選択してください</span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-12 mb-2 mt-2">
                <div class="form-group">
                    <input type="text" name="kosu" value="<?php echo e($juchu->kosu); ?>" class="form-control" placeholder="個数">
                    <?php $__errorArgs = ['kosu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red;">個数を1～12までの数値で入力してください</span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-12 mb-2 mt-2">
                    <button type="submit" class="btn btn-primary w-100">変更</button>
            </div>
        </div>      
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\work\lesson\laravel\bunbougu\resources\views/juchu/edit.blade.php ENDPATH**/ ?>


  
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="text-right">
                <h2 style="font-size:1rem;">ログイン者：<?php echo e($user_name); ?></h2>
              </div>
            <div class="text-left">
                <h2 style="font-size:1rem;">文房具マスター</h2>
            </div>
            <div class="text-right">
                <?php if(auth()->guard()->check()): ?>
                <a class="btn btn-success" href="<?php echo e(route('bunbougu.create')); ?>">新規登録</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <table class="table table-bordered">
      <tr>
          <th>No</th>
          <th>name</th>
          <th>kakaku</th>
          <th>bunrui</th>
          <th></th>
          <th></th>
          <th>編集者</th>
      </tr>
      <?php $__currentLoopData = $bunbougus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bunbougu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td style="text-align:right"><?php echo e($bunbougu->id); ?></td>
          
          
          <td><a href="<?php echo e(route('bunbougu.show',$bunbougu->id)); ?>?page_id=<?php echo e($page_id); ?>"><?php echo e($bunbougu->name); ?></a></td>
          <td style="text-align:right"><?php echo e($bunbougu->kakaku); ?>円</td>
          <td><?php echo e($bunbougu->bunrui); ?></td>
          <td style="text-align:center">
            <?php if(auth()->guard()->check()): ?>
            <a class="btn btn-primary" href="<?php echo e(route('bunbougu.edit',$bunbougu->id)); ?>">変更</a>
            <?php endif; ?>
          </td>
          <td style="text-align:center">
            <form action="<?php echo e(route('bunbougu.destroy',$bunbougu->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <?php if(auth()->guard()->check()): ?>
            <button type="submit" class="btn btn-sm btn-danger" onclick='return confirm("削除しますか？");'>削除</button>
            <?php endif; ?>
            </form>
          </td>
          <td><?php echo e($bunbougu->user->name); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>

  <?php echo $bunbougus->links('pagination::bootstrap-5'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\work\lesson\laravel\bunbougu\resources\views/index.blade.php ENDPATH**/ ?>
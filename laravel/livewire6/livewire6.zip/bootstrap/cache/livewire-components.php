<?php return array (
  'book-index' => 'App\\Http\\Livewire\\BookIndex',
);